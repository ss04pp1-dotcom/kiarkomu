# Shohure — Full Project Structure & Handoff Guide

> A full-stack Bangladeshi e-commerce platform: Express API + React Admin Dashboard + Expo React Native Mobile App + PostgreSQL database.

---

## Table of Contents

1. [High-Level Overview](#1-high-level-overview)
2. [Monorepo Layout](#2-monorepo-layout)
3. [Tech Stack](#3-tech-stack)
4. [Running the Project](#4-running-the-project)
5. [Environment Variables & Secrets](#5-environment-variables--secrets)
6. [Database — All Tables](#6-database--all-tables)
7. [API Server — All Routes](#7-api-server--all-routes)
8. [Admin Panel — All Pages](#8-admin-panel--all-pages)
9. [Mobile App — All Screens](#9-mobile-app--all-screens)
10. [Authentication & Roles](#10-authentication--roles)
11. [Key Features](#11-key-features)
12. [Google Sign-In Setup](#12-google-sign-in-setup)
13. [Firebase Setup (Chat Only)](#13-firebase-setup-chat-only)
14. [Email Setup (SMTP)](#14-email-setup-smtp)
15. [File Storage Options](#15-file-storage-options)
16. [Building the Android APK](#16-building-the-android-apk)
17. [Default Credentials](#17-default-credentials)
18. [Shared Libraries](#18-shared-libraries)
19. [API Code Generation](#19-api-code-generation)

---

## 1. High-Level Overview

Shohure is a complete e-commerce solution targeting the Bangladeshi market. It supports:

- Bengali language product names and descriptions
- bKash mobile banking payment flow
- Referral program with coin rewards
- Spin-wheel gamification
- Customer ↔ Admin real-time chat
- Google Sign-In for mobile users
- Flash sales, coupons, and banners
- Multi-zone shipping and store pickup

The platform has three deployable services that all run together:

| Service | What it does | Path |
|---|---|---|
| **API Server** | All backend logic, database, auth | `/api` |
| **Admin Panel** | Web dashboard for the shop owner | `/admin/` |
| **Mobile App** | Customer-facing Expo app | Root `/` (Expo domain) |

---

## 2. Monorepo Layout

```
workspace/
├── artifacts/
│   ├── api-server/          # Express 5 backend
│   │   ├── src/
│   │   │   ├── app.ts       # Express app setup, CORS, middleware
│   │   │   ├── index.ts     # Server entry point, ensureAdminUser()
│   │   │   ├── routes/      # All route files (one file per domain)
│   │   │   ├── middlewares/ # requireAuth.ts, adminAuth.ts
│   │   │   └── lib/         # auth.ts, crypto.ts, mailer.ts, push.ts,
│   │   │                    # storage-config.ts, verification-store.ts,
│   │   │                    # logger.ts, abandoned-cart-cron.ts
│   │   ├── public/uploads/  # Locally uploaded images served at /api/uploads/
│   │   ├── build.mjs        # esbuild bundle script
│   │   └── package.json
│   │
│   ├── admin/               # React + Vite admin dashboard
│   │   ├── src/
│   │   │   ├── App.tsx      # Router setup
│   │   │   ├── main.tsx     # React entry
│   │   │   ├── pages/       # One folder/file per page
│   │   │   ├── components/  # Shared UI (shadcn/ui + custom)
│   │   │   ├── lib/
│   │   │   │   ├── auth.tsx     # AuthContext + useAuth hook
│   │   │   │   ├── use-auth.ts  # Auth hook shorthand
│   │   │   │   └── firebase.ts  # Firestore (for admin chat)
│   │   │   └── hooks/
│   │   └── package.json
│   │
│   ├── mobile/              # Expo React Native app
│   │   ├── app/             # Expo Router file-based screens
│   │   │   ├── _layout.tsx      # Root layout (fonts, auth guard)
│   │   │   ├── (tabs)/          # Bottom-tab screens
│   │   │   ├── auth/            # login, register, forgot-password
│   │   │   ├── product/[id].tsx
│   │   │   ├── order/           # order detail + payment instruction
│   │   │   └── ...              # checkout, search, wishlist, etc.
│   │   ├── components/      # Reusable components
│   │   ├── contexts/        # AuthContext, ConfigContext, ThemeContext
│   │   ├── hooks/           # useColors, useGoogleConfig, useNotifications
│   │   ├── lib/             # firebase.ts, config.ts (fetches app config)
│   │   ├── constants/       # colors.ts
│   │   ├── server/          # Static production server + landing page HTML
│   │   ├── app.json         # Expo config (package: com.shohure.mobile)
│   │   └── package.json
│   │
│   └── mockup-sandbox/      # Vite-powered UI component preview (dev tool)
│
├── lib/
│   ├── db/                  # Drizzle ORM — schema + database client
│   │   ├── src/schema/      # One .ts file per table group
│   │   └── drizzle.config.ts
│   ├── api-spec/            # OpenAPI YAML spec + Orval codegen config
│   │   └── openapi.yaml     # Source of truth for API contracts
│   ├── api-client-react/    # Generated React Query hooks (from openapi.yaml)
│   └── api-zod/             # Generated Zod validation schemas (from openapi.yaml)
│
├── scripts/                 # Shared utility scripts
├── pnpm-workspace.yaml      # Workspace config, dependency catalog
├── tsconfig.base.json       # Shared TypeScript strict defaults
└── package.json             # Root dev tooling (typescript, prettier, eslint)
```

---

## 3. Tech Stack

| Layer | Technology |
|---|---|
| Package manager | pnpm workspaces |
| Runtime | Node.js 24 |
| Language | TypeScript 5.9 (strict mode) |
| API framework | Express 5 |
| Database | PostgreSQL (Replit-managed) |
| ORM | Drizzle ORM |
| Validation | Zod v4 + drizzle-zod |
| API contract | OpenAPI 3.x → Orval codegen |
| React queries | TanStack Query (React Query v5) |
| Admin UI | React 18 + Vite + Tailwind CSS v4 |
| Admin components | shadcn/ui (Radix UI primitives) |
| Admin routing | Wouter |
| Mobile framework | Expo SDK 55 + React Native |
| Mobile routing | Expo Router (file-based) |
| Mobile styling | NativeWind / StyleSheet |
| Auth | JWT (SESSION_SECRET) |
| Google Sign-In | expo-auth-session |
| Real-time chat | Firebase Firestore |
| Push notifications | Expo Notifications |
| Email | Nodemailer (SMTP) |
| File upload | Multer — local / Supabase / AWS S3 |
| Logging | Pino + pino-http |
| Build | esbuild (API server) |

---

## 4. Running the Project

All four services are managed as workflows. Start them in this order:

```bash
# 1. API Server (must start first — other services depend on it)
pnpm --filter @workspace/api-server run dev

# 2. Admin Panel
pnpm --filter @workspace/admin run dev

# 3. Mobile App
pnpm --filter @workspace/mobile run dev

# 4. (Optional) Component Preview Sandbox
pnpm --filter @workspace/mockup-sandbox run dev
```

### Push database schema (run once, or after schema changes)

The normal `pnpm --filter @workspace/db run push` has a TypeScript resolution issue with drizzle-kit. Use this workaround instead:

```bash
cd lib/db && node /path/to/workspace/node_modules/.pnpm/tsx@4.21.0/node_modules/tsx/dist/cli.mjs \
  /path/to/workspace/node_modules/.pnpm/drizzle-kit@0.31.9/node_modules/drizzle-kit/bin.cjs \
  push --config ./drizzle.config.ts
```

Or from the workspace root:
```bash
cd lib/db && node $(find ../../node_modules/.pnpm/tsx@4.21.0 -name "cli.mjs") \
  $(find ../../node_modules/.pnpm/drizzle-kit@0.31.9 -name "bin.cjs") \
  push --config ./drizzle.config.ts
```

### Regenerate API client after changing openapi.yaml

```bash
pnpm --filter @workspace/api-spec run codegen
```

---

## 5. Environment Variables & Secrets

### Required (app will not start without these)

| Variable | Where set | Purpose |
|---|---|---|
| `DATABASE_URL` | Replit auto-provided | PostgreSQL connection string |
| `SESSION_SECRET` | Replit Secret | JWT signing key for user sessions (all `/api/auth/*` routes) |
| `CONFIG_ENCRYPTION_KEY` | Replit Secret | 64-char hex key to encrypt sensitive values stored in the database (Firebase keys, Google secrets, etc.) |
| `ADMIN_EMAIL` | Replit Secret | Login email for the App Config panel inside the Admin Panel |
| `ADMIN_PASSWORD` | Replit Secret | Login password for the App Config panel |
| `ADMIN_JWT_SECRET` | Replit Secret | JWT signing key specifically for the App Config admin session |

### Auto-provided by Replit (do not set manually)

| Variable | Purpose |
|---|---|
| `REPLIT_DOMAINS` | Comma-separated list of public domains for this repl |
| `REPLIT_DEV_DOMAIN` | Development domain (used by mobile app as API base URL) |
| `REPL_ID` | Unique repl identifier |
| `REPLIT_EXPO_DEV_DOMAIN` | Expo-specific domain for Metro bundler |
| `PGDATABASE`, `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD` | Individual Postgres credentials |

### Optional — Email (registration & password reset)

| Variable | Purpose |
|---|---|
| `SMTP_HOST` | SMTP server hostname (e.g. smtp.gmail.com) |
| `SMTP_PORT` | SMTP port (usually 587 or 465) |
| `SMTP_SECURE` | `"true"` for SSL/465, `"false"` for TLS/587 |
| `SMTP_USER` | SMTP username / Gmail address |
| `SMTP_PASS` | SMTP password / Gmail App Password |
| `SMTP_FROM` | From address (e.g. noreply@shohure.com) |
| `SMTP_FROM_NAME` | Sender display name (e.g. Shohure) |

> Without SMTP configured, email verification and password reset are disabled. Users can still register via Google Sign-In.

### Optional — Firebase (real-time chat only)

Set these in Admin Panel → App Config, NOT as environment variables. They are stored encrypted in the database and served to clients at runtime.

The Firebase config is only needed if you want the real-time chat (Messages tab) to sync live across devices using Firestore.

### Optional — Google Sign-In

Also configured in Admin Panel → App Config (not env vars):
- `googleWebClientId` — required for Google Sign-In on all platforms
- `googleAndroidClientId` — required for native Android sign-in
- `googleIosClientId` — required for native iOS sign-in

---

## 6. Database — All Tables

All tables are defined in `lib/db/src/schema/`. The database client is exported from `lib/db/src/index.ts`.

### `users`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text | Display name |
| email | text UNIQUE | Normalized to lowercase |
| password_hash | text | bcrypt hash, or `google:<googleId>` for OAuth users |
| phone | text | Optional |
| avatar_url | text | Profile picture URL |
| role | enum | `customer`, `manager`, `owner` |
| referral_code | text UNIQUE | 8-char uppercase hex |
| push_token | text | Expo push notification token |
| is_active | boolean | Default true |
| reset_token | text | Password reset OTP code |
| reset_token_expiry | timestamp | Reset token expires in 15 min |
| created_at / updated_at | timestamp | |

### `categories`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text UNIQUE | English name |
| name_bn | text | Bengali name |
| icon_url | text | Icon image URL |
| sort_order | integer | Display order |

### `brands`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text UNIQUE | |
| logo_url | text | |
| description | text | |

### `products`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text | English name |
| name_bn | text | Bengali name |
| slug | text UNIQUE | URL-friendly identifier |
| description | text | |
| category_id | int FK → categories | Cascade delete |
| brand_id | int FK → brands | Set null on delete |
| stock | integer | Total stock (sum of variants if variants exist) |
| price | numeric | Base price |
| discount_price | numeric | Sale price |
| thumbnail_url | text | Main product image |
| images | jsonb | Array of additional image URLs |
| tags | text[] | Searchable tags |
| is_active | boolean | Visible to customers |
| created_at / updated_at | timestamp | |

### `product_variants`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| product_id | int FK → products | Cascade delete |
| type | text | e.g. "color", "size" |
| value | text | e.g. "Red", "XL" |
| price | numeric | Optional variant-specific price |
| stock | integer | Variant-specific stock |

### `recently_viewed`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| product_id | int FK → products | |
| viewed_at | timestamp | |

### `orders`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| status | enum | `pending`, `confirmed`, `processing`, `shipped`, `delivered`, `cancelled` |
| payment_status | enum | `unpaid`, `pending`, `paid`, `failed` |
| payment_method | text | e.g. "bkash", "cod" |
| address_id | int FK → addresses | Delivery address snapshot |
| store_id | int FK → stores | If pickup from store |
| coupon_code | text | Applied coupon |
| subtotal / discount / delivery_charge / total | numeric | Order amounts |
| coins_used | integer | Coins redeemed |
| notes | text | Customer notes |
| transaction_id | text | Payment transaction ID |
| sender_number | text | bKash sender number |
| ssl_session_key | text | Payment gateway session |

### `order_items`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| order_id | int FK → orders | Cascade delete |
| product_id | int FK → products | |
| variant_id | int FK → product_variants | Optional |
| product_name | text | Snapshot at time of order |
| thumbnail_url | text | Snapshot at time of order |
| unit_price / quantity / total | numeric/int | |

### `order_tracking`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| order_id | int FK → orders | |
| status | text | Tracking status |
| note | text | Note from admin |
| created_at | timestamp | |

### `addresses`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| label | text | e.g. "Home", "Office" |
| recipient_name | text | |
| phone | text | |
| address_line | text | Street address |
| city / area / district | text | |
| is_default | boolean | |

### `carts`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| product_id | int FK → products | |
| variant_id | int FK → product_variants | Optional |
| quantity | integer | |
| added_at | timestamp | |

### `coupons`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| code | text UNIQUE | Coupon code |
| discount_type | enum | `percentage`, `fixed` |
| discount_value | numeric | |
| min_order_amount | numeric | Minimum cart total to apply |
| max_uses | integer | Usage limit (null = unlimited) |
| used_count | integer | |
| expires_at | timestamp | |
| is_active | boolean | |

### `banners`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| title | text | |
| image_url | text | Banner image |
| link_url | text | Where it links to |
| sort_order | integer | Display order |
| is_active | boolean | |

### `flash_sales`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| title | text | |
| discount_percent | integer | e.g. 20 for 20% off |
| product_ids | integer[] | Array of product IDs included |
| starts_at / ends_at | timestamp | |
| is_active | boolean | |

### `reviews`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| product_id | int FK → products | |
| user_id | int FK → users | |
| order_id | int FK → orders | Ensures verified purchase |
| rating | integer | 1–5 |
| comment | text | |
| is_approved | boolean | Admin moderation |
| created_at | timestamp | |

### `notifications`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| title | text | |
| body | text | |
| type | text | e.g. "order_update", "general" |
| read | boolean | |
| created_at | timestamp | |

### `shipping_zones`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text | Zone name (e.g. "Dhaka City") |
| areas | text[] | List of covered areas/cities |
| charge | numeric | Delivery charge for this zone |
| estimated_days | integer | Estimated delivery days |

### `stores` (pickup locations)
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| name | text | Store name |
| address | text | Physical address |
| phone | text | |
| is_active | boolean | |

### `messages`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| sender_id | int FK → users | |
| receiver_id | int FK → users | |
| content | text | Message text |
| image_url | text | Optional image |
| is_read | boolean | |
| created_at | timestamp | |

### `auto_replies`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| trigger_keyword | text | Keyword that triggers this reply |
| reply_text | text | Automated response |
| is_active | boolean | |

### `app_config`
| Column | Type | Notes |
|---|---|---|
| id | text PK | Always `"mobile"` |
| config | jsonb | Full config object (see AppConfig type below) |

**AppConfig fields:**
- `apiBaseUrl` — API base URL served to mobile app
- `googleWebClientId` — Google OAuth Web Client ID
- `googleAndroidClientId` — Google OAuth Android Client ID
- `googleIosClientId` — Google OAuth iOS Client ID
- `googleClientSecret` — Google OAuth client secret (stored encrypted)
- `appEmail` — Support email address shown in app
- `appPassword` — Email password (stored encrypted)
- `featureFlags` — Key-value feature toggles
- `storageProvider` — `"local"` | `"supabase"` | `"aws_s3"`
- `supabaseUrl`, `supabaseServiceKey`, `supabaseBucket` — Supabase storage config
- `awsAccessKey`, `awsSecretKey`, `awsRegion`, `awsBucket` — AWS S3 config

### `app_settings`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| site_name | text | Shop name |
| site_logo_url | text | Logo URL |
| currency | text | Default: "BDT" |
| currency_symbol | text | Default: "৳" |
| contact_email | text | |
| contact_phone | text | |
| address | text | Physical address |
| social_links | jsonb | Facebook, Instagram, etc. |
| meta_title / meta_description | text | SEO fields |

### `referrals`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| referrer_id | int FK → users | Who referred |
| referred_id | int FK → users | Who signed up |
| coins_awarded | integer | Default 50 coins each |
| created_at | timestamp | |

### `user_coins`
| Column | Type | Notes |
|---|---|---|
| user_id | int FK → users PK | One row per user |
| balance | integer | Current coin balance |

### `coin_transactions`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| type | text | `"referral"`, `"purchase"`, `"spin"`, `"redeem"` |
| amount | integer | Positive = earned, negative = spent |
| description | text | |
| created_at | timestamp | |

### `wishlists`
| Column | Type | Notes |
|---|---|---|
| id | serial PK | |
| user_id | int FK → users | |
| product_id | int FK → products | |
| added_at | timestamp | |

### `gamification` (spin wheel)
*(Schema in `lib/db/src/schema/gamification.ts`)*

Tracks spin wheel prizes and user spin history.

---

## 7. API Server — All Routes

Base path: `/api`

All protected routes require `Authorization: Bearer <token>` header.

Role levels: `customer` < `manager` < `owner`

### Health
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/healthz` | None | Health check, returns `{ status: "ok" }` |

### Auth
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/send-verification` | None | Send 6-digit email verification code (rate limited: 3/10min) |
| POST | `/auth/verify-email-code` | None | Verify the emailed code before registration |
| POST | `/auth/register` | None | Register with name, email, password, verification code |
| POST | `/auth/login` | None | Login with email + password (rate limited: 10/15min) |
| POST | `/auth/google` | None | Login or register with Google access token |
| POST | `/auth/logout` | None | Logout (client-side token deletion) |
| GET | `/auth/me` | User | Get current user profile |
| PATCH | `/auth/me` | User | Update name, phone, avatarUrl, pushToken |
| POST | `/auth/forgot-password` | None | Send password reset OTP to email |
| POST | `/auth/reset-password` | None | Reset password using OTP |
| POST | `/auth/change-email` | User | Change email (requires current password) |
| POST | `/auth/change-password` | User | Change password (requires current password) |

### Products
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/products` | None | List all active products (supports filters: category, brand, search, sort, page) |
| POST | `/products` | Owner | Create a new product |
| GET | `/products/recommended` | User | Products recommended for the current user |
| GET | `/products/:id` | None | Get single product with variants |
| PATCH | `/products/:id` | Owner | Update product |
| DELETE | `/products/:id` | Owner | Delete product |
| GET | `/products/:id/reviews` | None | Get approved reviews for a product |
| POST | `/products/:id/reviews` | User | Submit a review (must have a delivered order containing this product) |
| GET | `/products/:id/can-review` | User | Check if user is eligible to review |
| GET | `/products/:id/frequently-bought-together` | None | Products often ordered with this product |
| POST | `/products/:id/track-view` | User | Record a product view (used for analytics + recently viewed) |

### Categories
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/categories` | None | List all categories |
| POST | `/categories` | Owner | Create category |
| GET | `/categories/:id` | None | Get category with its products |
| PATCH | `/categories/:id` | Owner | Update category |
| DELETE | `/categories/:id` | Owner | Delete category |

### Brands
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/brands` | None | List all brands |
| POST | `/brands` | Owner | Create brand |
| PATCH | `/brands/:id` | Owner | Update brand |
| DELETE | `/brands/:id` | Owner | Delete brand |

### Cart
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/cart` | User | Get current user's cart |
| DELETE | `/cart` | User | Clear entire cart |
| POST | `/cart/items` | User | Add item to cart |
| PATCH | `/cart/items/:itemId` | User | Update item quantity |
| DELETE | `/cart/items/:itemId` | User | Remove item from cart |

### Orders
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/orders` | User | List orders (customers see their own; owners see all) |
| POST | `/orders` | User | Place a new order |
| GET | `/orders/:id` | User | Get order details with items |
| PATCH | `/orders/:id` | Owner/Manager | Update order status or payment status |
| POST | `/orders/:id/submit-payment` | User | Submit bKash payment (transaction ID + sender number) |
| GET | `/orders/:id/tracking` | User | Get tracking history |
| POST | `/orders/:id/tracking` | Owner/Manager | Add tracking update |
| POST | `/orders/:id/initiate-payment` | User | Initiate payment gateway session |
| GET | `/orders/:id/invoice` | User | Download order invoice (returns HTML) |
| POST | `/payments/webhook` | None | Payment gateway webhook placeholder |
| POST | `/payments/success` | None | Payment success callback |
| POST | `/payments/fail` | None | Payment failure callback |

### Wishlist
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/wishlist` | User | Get current user's wishlist |
| POST | `/wishlist/:productId` | User | Add product to wishlist |
| DELETE | `/wishlist/:productId` | User | Remove from wishlist |

### Coupons
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/coupons` | Owner | List all coupons |
| POST | `/coupons` | Owner | Create coupon |
| PATCH | `/coupons/:id` | Owner | Update coupon |
| DELETE | `/coupons/:id` | Owner | Delete coupon |
| POST | `/coupons/validate` | None | Validate a coupon code against a cart total |

### Banners
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/banners` | None | List all active banners |
| POST | `/banners` | Owner | Create banner |
| PATCH | `/banners/:id` | Owner | Update banner |
| DELETE | `/banners/:id` | Owner | Delete banner |

### Flash Sales
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/flash-sales` | None | List all flash sales |
| POST | `/flash-sales` | Owner | Create flash sale |
| GET | `/flash-sales/active` | None | Get currently active flash sales |
| PATCH | `/flash-sales/:id` | Owner | Update flash sale |
| DELETE | `/flash-sales/:id` | Owner | Delete flash sale |

### Reviews
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/reviews` | Owner/Manager | List all reviews (pending approval) |
| PATCH | `/reviews/:id` | Owner/Manager | Approve or reject a review |
| DELETE | `/reviews/:id` | Owner/Manager | Delete a review |

### Shipping
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/shipping/calculate` | None | Calculate delivery charge for an area + cart total |
| GET | `/shipping/zones` | Owner | List shipping zones |
| POST | `/shipping/zones` | Owner | Create shipping zone |
| PATCH | `/shipping/zones/:id` | Owner | Update zone |
| DELETE | `/shipping/zones/:id` | Owner | Delete zone |

### Stores (Pickup Locations)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/stores` | None | List all active pickup stores |
| POST | `/stores` | Owner | Create store |
| PATCH | `/stores/:id` | Owner | Update store |
| DELETE | `/stores/:id` | Owner | Delete store |

### Addresses
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/addresses` | User | List current user's addresses |
| POST | `/addresses` | User | Add new address |
| PATCH | `/addresses/:id` | User | Update address |
| DELETE | `/addresses/:id` | User | Delete address |

### Messages (Customer ↔ Admin Chat)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/messages` | User | Get messages between current user and admin |
| POST | `/messages` | User | Send a message |
| GET | `/messages/conversations` | User | List all conversations (owners see all; customers see their own) |
| PATCH | `/messages/mark-read/:userId` | User | Mark all messages from a user as read |
| PATCH | `/messages/:id/read` | User | Mark single message as read |
| GET | `/auto-replies` | Owner | List auto-reply rules |
| POST | `/auto-replies` | Owner | Create auto-reply rule |
| PATCH | `/auto-replies/:id` | Owner | Update auto-reply rule |
| DELETE | `/auto-replies/:id` | Owner | Delete auto-reply rule |

### Notifications
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/notifications` | User | Get current user's notifications |
| PATCH | `/notifications/:id/read` | User | Mark notification as read |
| PATCH | `/notifications/read-all` | User | Mark all notifications as read |
| POST | `/notifications/broadcast` | Owner/Manager | Send push notification to all users |
| DELETE | `/notifications/:id` | User | Delete a notification |

### Analytics
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/analytics/summary` | Owner/Manager | Total revenue, orders, customers, products |
| GET | `/analytics/sales-over-time` | Owner/Manager | Daily/weekly/monthly sales chart data |
| GET | `/analytics/top-products` | Owner/Manager | Best-selling products |
| GET | `/analytics/top-categories` | Owner/Manager | Best-performing categories |
| GET | `/analytics/conversion-rate` | Owner/Manager | View-to-purchase conversion rate |
| GET | `/analytics/high-view-low-sale` | Owner/Manager | Products with high views but low sales |
| GET | `/analytics/top-customers` | Owner/Manager | Highest-spending customers |

### Settings
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/settings` | None | Get public app settings (site name, logo, etc.) |
| PATCH | `/settings` | Owner | Update app settings |

### App Config (separate admin auth)
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/admin/login` | None (uses ADMIN_EMAIL/ADMIN_PASSWORD) | Login to the app config panel |
| GET | `/config/mobile` | None | Get safe config for mobile app (excludes secrets) |
| GET | `/config/admin` | Admin JWT | Get full config including decrypted secrets |
| PATCH | `/config/mobile` | Admin JWT | Update app config |
| PUT | `/config/mobile` | Admin JWT | Replace app config |

### File Upload
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/upload` | User | Upload an image file (returns URL) |
| POST | `/admin/upload` | Admin JWT | Upload image from config panel |

Uploaded files are served at `/api/uploads/<filename>`.

### Users
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/users` | Owner/Manager | List all registered customers |

### Seed
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/seed` | Owner | Seed the database with sample data |

---

## 8. Admin Panel — All Pages

Access at `/admin/`. Login with `admin@shohure.com` / `Admin@1234`.

| Page | Path | Description |
|---|---|---|
| Login | `/admin/login` | Email + password login screen |
| Dashboard | `/admin/` | Summary cards (revenue, orders, customers), charts |
| Products | `/admin/products` | Paginated product list, search, filter |
| New Product | `/admin/products/new` | Create product with variants, images, pricing |
| Edit Product | `/admin/products/:id/edit` | Edit existing product |
| Bulk Products | `/admin/products/bulk` | Bulk import/export products |
| Categories | `/admin/categories` | List, create, edit, delete categories |
| Brands | `/admin/brands` | List, create, edit, delete brands |
| Orders | `/admin/orders` | All orders, filter by status, date |
| Order Detail | `/admin/orders/:id` | Full order details, update status, add tracking |
| Customers | `/admin/customers` | All registered users |
| Reviews | `/admin/reviews` | Pending/approved/rejected reviews |
| Coupons | `/admin/coupons` | Manage discount coupons |
| Banners | `/admin/banners` | Homepage banner images |
| Flash Sales | `/admin/flash-sales` | Time-limited discount events |
| Promo Cards | `/admin/promo-cards` | Promotional card content |
| Stock | `/admin/stock` | Low-stock product view |
| Shipping | `/admin/shipping` | Shipping zones and pickup stores |
| Chat | `/admin/chat` | Real-time customer messages |
| Notifications | `/admin/notifications` | Send broadcast push notifications |
| Admins | `/admin/admins` | Admin user management |
| Settings | `/admin/settings` | Site name, logo, currency, contact info |
| App Config | `/admin/app-config` | Mobile app config (Google OAuth, Firebase, storage) |

---

## 9. Mobile App — All Screens

The app uses **Expo Router** with file-based routing. All screens are in `artifacts/mobile/app/`.

### Bottom Tab Screens (`app/(tabs)/`)
| File | Tab | Description |
|---|---|---|
| `index.tsx` | Home | Banners, flash sales, categories, popular products, promo cards |
| `categories.tsx` | Categories | Browse all categories and brands |
| `cart.tsx` | Cart | Shopping cart, coupon, shipping, place order |
| `messages.tsx` | Message | Customer ↔ Admin chat |
| `account.tsx` | Account | Login/register prompt or user profile with quick links |

### Product & Shopping
| File | Description |
|---|---|
| `product/[id].tsx` | Product detail: images, variants, add to cart, reviews, frequently bought together |
| `checkout.tsx` | Full checkout: address, delivery method, payment method, coupon, coin redemption |
| `wishlist.tsx` | Saved/wishlist products |
| `search.tsx` | Full-text product search with filters |

### Orders
| File | Description |
|---|---|
| `orders.tsx` | Order history list with status badges |
| `order/[id].tsx` | Order detail: items, amounts, tracking timeline |
| `order/payment-instruction.tsx` | bKash payment instructions with transaction ID submission |

### Auth
| File | Description |
|---|---|
| `auth/login.tsx` | Email + password login, Google Sign-In button |
| `auth/register.tsx` | Two-step: form → email verification OTP |
| `auth/forgot-password.tsx` | Request OTP → reset password |

### Account & Profile
| File | Description |
|---|---|
| `profile-edit.tsx` | Edit name, phone, avatar |
| `addresses.tsx` | Manage delivery addresses |
| `settings.tsx` | App preferences |
| `notifications.tsx` | Notification history |
| `referrals.tsx` | Referral program: share code, see earned coins |
| `spin-wheel.tsx` | Spin the wheel to earn coins (gamification) |

---

## 10. Authentication & Roles

### User Auth (Mobile App & API)

- JWT tokens signed with `SESSION_SECRET`, expire in 30 days
- Token stored in mobile app via `AsyncStorage`
- Sent as `Authorization: Bearer <token>` header on every API request
- Three roles: `customer`, `manager`, `owner`
- First user to register with the email matching `INITIAL_ADMIN_EMAIL` env var gets `owner` role automatically
- Default seeded owner: `admin@shohure.com` / `Admin@1234`

### Admin Config Panel Auth (inside Admin Panel)

- Separate JWT signed with `ADMIN_JWT_SECRET`, expire in 7 days
- Used only for the App Config page
- Credentials are `ADMIN_EMAIL` and `ADMIN_PASSWORD` env vars
- Token stored in `localStorage` under key `shohure_admin_config_jwt`

### Google Sign-In Flow

1. Mobile app calls `expo-auth-session` with `googleWebClientId` / `googleAndroidClientId`
2. Google returns an access token
3. App fetches user info from Google's userinfo endpoint
4. App sends `{ email, name, googleId, avatarUrl }` to `POST /api/auth/google`
5. Backend creates or updates the user record
6. Backend returns JWT + user object
7. App stores the JWT and logs the user in

No Firebase is needed for Google Sign-In. The flow is purely OAuth.

---

## 11. Key Features

| Feature | Where implemented |
|---|---|
| Product catalog with variants (color, size) | `products`, `product_variants` tables + products route |
| Bengali language support | `name_bn` fields on products and categories |
| Shopping cart (persistent, synced to server) | `carts` table + cart route |
| Order placement and management | `orders`, `order_items` tables + orders route |
| bKash payment submission flow | Orders route + payment-instruction screen |
| Coupon system (% or fixed discount) | `coupons` table + promotions route |
| Banner management | `banners` table + promotions route |
| Flash sales with countdown | `flash_sales` table + promotions route |
| Product reviews (verified purchase only) | `reviews` table + can-review check |
| Wishlist | `wishlists` table + wishlist route |
| Customer ↔ Admin real-time chat | `messages` table + Firebase Firestore for live sync |
| Auto-reply messages | `auto_replies` table |
| Push notifications | Expo Notifications + `push_token` on user |
| Broadcast notifications | notifications/broadcast route |
| Referral program (50 coins each) | `referrals`, `user_coins`, `coin_transactions` tables |
| Spin wheel gamification | `gamification` table |
| Shipping zones | `shipping_zones` table + shipping/calculate endpoint |
| Store pickup | `stores` table |
| Delivery address book | `addresses` table |
| Analytics dashboard | analytics routes (7 endpoints) |
| Google Sign-In | expo-auth-session + /api/auth/google |
| Email verification on registration | verification-store.ts (in-memory) + mailer.ts |
| Password reset via email OTP | reset_token fields on users + mailer.ts |
| Abandoned cart cron | `abandoned-cart-cron.ts` (sends push/notifications) |
| File uploads | Multer → local disk / Supabase Storage / AWS S3 |
| Encrypted config storage | crypto.ts AES-256 + CONFIG_ENCRYPTION_KEY |
| Multi-storage backend | storage-config.ts (local / Supabase / S3) |
| SEO / metadata settings | app_settings table |

---

## 12. Google Sign-In Setup

### For web testing (Expo Go)

1. Go to [console.cloud.google.com](https://console.cloud.google.com) → APIs & Services → Credentials
2. Create OAuth 2.0 Client ID → Web application
3. Add authorized redirect URI: `https://auth.expo.io/@salman672005/com.shohure.mobile`
4. Copy the **Web Client ID**
5. In Admin Panel → App Config → enter it as **Google Web Client ID** → Save

### For production Android APK

1. Build the app once with EAS to get the SHA-1 fingerprint: `eas credentials`
2. Create another OAuth 2.0 Client ID → Android
   - Package name: `com.shohure.mobile`
   - SHA-1: from step 1
3. Copy the **Android Client ID**
4. In Admin Panel → App Config → enter both Web Client ID and Android Client ID → Save

---

## 13. Firebase Setup (Chat Only)

Firebase is only needed for the real-time chat feature (Messages tab). Without it, the chat still works but won't update in real time — users would need to refresh to see new messages.

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → Create project
2. Add a Web app to get the config object
3. Enable **Cloud Firestore** in the Firebase console
4. In Admin Panel → App Config → enter the Firebase config values:
   - API Key, Auth Domain, Project ID, Storage Bucket, Messaging Sender ID, App ID
5. The config is stored encrypted in the database and served to mobile/admin at runtime

---

## 14. Email Setup (SMTP)

Email is used for:
- Registration email verification codes
- Password reset OTP codes

Recommended: use a **Gmail App Password** (not your regular Gmail password).

1. Enable 2-Factor Authentication on your Google account
2. Go to myaccount.google.com → Security → App Passwords → Create
3. Add these Replit Secrets:

| Secret | Value |
|---|---|
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `SMTP_SECURE` | `false` |
| `SMTP_USER` | your Gmail address |
| `SMTP_PASS` | the 16-character App Password |
| `SMTP_FROM` | your Gmail address |
| `SMTP_FROM_NAME` | `Shohure` |

---

## 15. File Storage Options

Uploaded product images default to local disk at `artifacts/api-server/public/uploads/` and are served at `/api/uploads/<filename>`.

To switch to cloud storage, go to Admin Panel → App Config → Storage Provider:

| Provider | Required config |
|---|---|
| **Local** (default) | Nothing extra needed |
| **Supabase Storage** | Supabase URL, Service Key, Bucket name |
| **AWS S3** | Access Key, Secret Key, Region, Bucket name |

---

## 16. Building the Android APK

The mobile app uses **Expo** with `eas-cli` for building.

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account (owner: salman672005)
eas login

# Navigate to mobile app
cd artifacts/mobile

# Configure build (first time only)
eas build:configure

# Build Android APK (for testing, direct install)
eas build --platform android --profile preview

# Build Android AAB (for Play Store submission)
eas build --platform android --profile production
```

**App details:**
- Name: `Shohure`
- Expo slug: `shohore`
- Expo owner: `salman672005`
- Android package: `com.shohure.mobile`
- iOS bundle ID: `com.shohure.mobile`

**Before building for production:**
1. Set `EXPO_PUBLIC_DOMAIN` in the build environment to your production API domain
2. Configure Google Android Client ID in Admin Panel → App Config
3. Set up Firebase if you want real-time chat

---

## 17. Default Credentials

| Where | Email | Password | Notes |
|---|---|---|---|
| Admin Panel login (`/admin/`) | `admin@shohure.com` | `Admin@1234` | Created automatically on first server start |
| App Config panel (inside admin) | Value of `ADMIN_EMAIL` secret | Value of `ADMIN_PASSWORD` secret | You set these as Replit Secrets |

---

## 18. Shared Libraries

All shared code lives in `lib/` and is referenced by workspace packages using `@workspace/<name>`.

### `@workspace/db`
- Exports `db` (Drizzle database client)
- Exports all table schemas and types
- Located at `lib/db/`

### `@workspace/api-client-react`
- Generated React Query hooks for every API endpoint
- e.g. `useGetProducts()`, `usePostOrders()`, `useGetAuthMe()`
- Located at `lib/api-client-react/`

### `@workspace/api-zod`
- Generated Zod schemas matching the OpenAPI spec
- Located at `lib/api-zod/`

### `@workspace/api-spec`
- Contains `openapi.yaml` — the source of truth for API contracts
- Running `pnpm --filter @workspace/api-spec run codegen` regenerates both `api-client-react` and `api-zod`
- Located at `lib/api-spec/`

---

## 19. API Code Generation

The project uses a contract-first API design. The flow is:

```
lib/api-spec/openapi.yaml
        ↓ (pnpm --filter @workspace/api-spec run codegen)
        ↓
lib/api-client-react/src/generated/   ← React Query hooks
lib/api-zod/src/generated/            ← Zod schemas
```

**When to regenerate:**
- After adding or changing any API endpoint
- After changing request/response shapes

**Do not manually edit** the files in `src/generated/` — they will be overwritten.

---

*Document generated: May 2026 | Project owner: salman672005 | App package: com.shohure.mobile*
