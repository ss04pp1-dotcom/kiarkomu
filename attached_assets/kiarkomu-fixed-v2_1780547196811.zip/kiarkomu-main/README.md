# Shohure E-Commerce Platform

বাংলাদেশের জন্য তৈরি একটি ফুল-স্ট্যাক ই-কমার্স প্ল্যাটফর্ম। Express API, React Admin Panel এবং Expo React Native মোবাইল অ্যাপ নিয়ে গঠিত।

---

## প্রজেক্ট স্ট্রাকচার

```
shohure/
│
├── package.json                          ← Root workspace (pnpm)
├── pnpm-workspace.yaml
├── tsconfig.base.json                    ← Shared TypeScript config
├── tsconfig.json
├── .npmrc                                ← pnpm settings
│
├── lib/                                  ← Shared libraries (workspace packages)
│   │
│   ├── db/                               ← @workspace/db
│   │   ├── src/
│   │   │   ├── index.ts                  ← Drizzle DB connection + re-export
│   │   │   └── schema/                   ← সব DB টেবিল
│   │   │       ├── index.ts
│   │   │       ├── users.ts
│   │   │       ├── products.ts
│   │   │       ├── categories.ts
│   │   │       ├── orders.ts             ← order, orderItems টেবিল
│   │   │       ├── carts.ts
│   │   │       ├── addresses.ts
│   │   │       ├── brands.ts
│   │   │       ├── shipping.ts
│   │   │       ├── promotions.ts         ← coupon, flashSale, promoCard, banner
│   │   │       ├── reviews.ts
│   │   │       ├── messages.ts
│   │   │       ├── notifications.ts
│   │   │       ├── wishlists.ts
│   │   │       ├── gamification.ts       ← coins, spinWheel
│   │   │       ├── settings.ts
│   │   │       └── app-config.ts
│   │   ├── drizzle/                      ← Migration files
│   │   │   ├── 0000_loose_grey_gargoyle.sql
│   │   │   ├── 0001_overhaul_migrations.sql
│   │   │   ├── 0002_mfs_payment.sql
│   │   │   ├── supabase_migration.sql
│   │   │   └── meta/
│   │   ├── drizzle.config.ts
│   │   └── package.json
│   │
│   ├── api-spec/                         ← @workspace/api-spec
│   │   ├── openapi.yaml                  ← OpenAPI 3.1 spec (সত্যের উৎস)
│   │   └── orval.config.ts               ← Code generation config
│   │
│   ├── api-zod/                          ← @workspace/api-zod (generated)
│   │   └── src/generated/
│   │       └── api.ts                    ← OpenAPI থেকে Zod schemas
│   │
│   └── api-client-react/                 ← @workspace/api-client-react (generated)
│       └── src/
│           ├── generated/
│           │   ├── api.ts                ← React Query hooks (auto-generated)
│           │   └── api.schemas.ts
│           ├── custom-fetch.ts           ← Auth header + base URL injection
│           └── index.ts
│
├── artifacts/                            ← Deployable apps
│   │
│   ├── api-server/                       ← @workspace/api-server (Express 5)
│   │   ├── src/
│   │   │   ├── index.ts                  ← Server entry, port listen
│   │   │   ├── app.ts                    ← Express app, CORS, middleware
│   │   │   ├── routes/
│   │   │   │   ├── index.ts              ← সব route একত্রিত
│   │   │   │   ├── auth.ts               ← Register, login, OTP, Google
│   │   │   │   ├── products.ts           ← CRUD + variants + stock
│   │   │   │   ├── categories.ts
│   │   │   │   ├── brands.ts
│   │   │   │   ├── orders.ts             ← Orders + invoice PDF endpoint
│   │   │   │   ├── cart.ts
│   │   │   │   ├── addresses.ts
│   │   │   │   ├── reviews.ts
│   │   │   │   ├── wishlist.ts
│   │   │   │   ├── shipping.ts
│   │   │   │   ├── promotions.ts         ← Coupons, flash sales, banners
│   │   │   │   ├── messages.ts
│   │   │   │   ├── notifications.ts
│   │   │   │   ├── analytics.ts
│   │   │   │   ├── upload.ts             ← Image upload (local/Supabase/S3)
│   │   │   │   ├── settings.ts           ← Store settings
│   │   │   │   ├── app-config.ts         ← Mobile app config (Firebase keys etc.)
│   │   │   │   ├── seed.ts               ← Dev seed data
│   │   │   │   └── health.ts
│   │   │   ├── middlewares/
│   │   │   │   ├── requireAuth.ts        ← User JWT verification
│   │   │   │   └── adminAuth.ts          ← Admin JWT verification
│   │   │   └── lib/
│   │   │       ├── auth.ts               ← JWT sign/verify, password hash
│   │   │       ├── mailer.ts             ← SMTP email (OTP, order confirm)
│   │   │       ├── push.ts               ← Firebase push notifications
│   │   │       ├── storage-config.ts     ← Supabase/S3/local image storage
│   │   │       ├── crypto.ts             ← AES-256-GCM encrypt/decrypt
│   │   │       ├── verification-store.ts ← OTP store (in-memory)
│   │   │       ├── abandoned-cart-cron.ts
│   │   │       ├── disposable-domains.ts ← Fake email block list
│   │   │       └── logger.ts             ← Pino logger
│   │   ├── public/uploads/               ← Local image storage folder
│   │   ├── build.mjs                     ← esbuild config
│   │   ├── tsconfig.json
│   │   └── package.json
│   │
│   ├── admin/                            ← @workspace/admin (React + Vite)
│   │   ├── src/
│   │   │   ├── main.tsx
│   │   │   ├── App.tsx                   ← Routes + auth guard
│   │   │   ├── index.css                 ← Tailwind + Inter font
│   │   │   ├── pages/
│   │   │   │   ├── dashboard.tsx         ← Analytics overview
│   │   │   │   ├── login.tsx
│   │   │   │   ├── not-found.tsx
│   │   │   │   ├── app-config.tsx        ← Firebase/SMTP/Storage config
│   │   │   │   ├── products/
│   │   │   │   │   ├── index.tsx         ← Product list
│   │   │   │   │   ├── new.tsx
│   │   │   │   │   ├── edit.tsx
│   │   │   │   │   ├── form.tsx          ← Shared product form
│   │   │   │   │   └── bulk.tsx          ← Bulk import
│   │   │   │   ├── orders/
│   │   │   │   │   ├── index.tsx         ← Order list + filters
│   │   │   │   │   └── detail.tsx        ← ★ Order detail + Invoice download
│   │   │   │   ├── categories/index.tsx
│   │   │   │   ├── brands/index.tsx
│   │   │   │   ├── customers/index.tsx
│   │   │   │   ├── admins/index.tsx
│   │   │   │   ├── reviews/index.tsx
│   │   │   │   ├── coupons/index.tsx
│   │   │   │   ├── flash-sales/index.tsx
│   │   │   │   ├── banners/index.tsx
│   │   │   │   ├── promo-cards/index.tsx
│   │   │   │   ├── shipping/index.tsx
│   │   │   │   ├── stores/index.tsx
│   │   │   │   ├── stock/index.tsx
│   │   │   │   ├── notifications/index.tsx
│   │   │   │   ├── chat/index.tsx
│   │   │   │   └── settings/index.tsx
│   │   │   ├── components/
│   │   │   │   ├── layout.tsx            ← Sidebar + header shell
│   │   │   │   ├── image-upload.tsx
│   │   │   │   └── ui/                   ← shadcn/ui components (30+)
│   │   │   ├── hooks/
│   │   │   │   ├── use-toast.ts
│   │   │   │   └── use-mobile.tsx
│   │   │   └── lib/
│   │   │       ├── auth.tsx              ← AuthContext + token storage
│   │   │       ├── use-auth.ts
│   │   │       ├── firebase.ts
│   │   │       └── utils.ts
│   │   ├── public/
│   │   ├── index.html
│   │   ├── vite.config.ts
│   │   ├── tsconfig.json
│   │   ├── components.json               ← shadcn/ui config
│   │   └── package.json
│   │
│   ├── mobile/                           ← @workspace/mobile (Expo SDK 55)
│   │   ├── app/                          ← Expo Router screens
│   │   │   ├── _layout.tsx               ← Root layout, auth, theme, base URL
│   │   │   ├── +not-found.tsx
│   │   │   ├── global.css
│   │   │   ├── (tabs)/                   ← Bottom tab screens
│   │   │   │   ├── _layout.tsx
│   │   │   │   ├── index.tsx             ← Home feed
│   │   │   │   ├── categories.tsx
│   │   │   │   ├── cart.tsx
│   │   │   │   ├── messages.tsx
│   │   │   │   └── account.tsx
│   │   │   ├── auth/
│   │   │   │   ├── login.tsx
│   │   │   │   ├── register.tsx
│   │   │   │   └── forgot-password.tsx
│   │   │   ├── product/[id].tsx          ← Product detail
│   │   │   ├── order/
│   │   │   │   ├── [id].tsx              ← ★ Order detail + Invoice download
│   │   │   │   └── payment-instruction.tsx
│   │   │   ├── orders.tsx                ← Order list
│   │   │   ├── checkout.tsx
│   │   │   ├── addresses.tsx
│   │   │   ├── wishlist.tsx
│   │   │   ├── notifications.tsx
│   │   │   ├── profile-edit.tsx
│   │   │   ├── referrals.tsx
│   │   │   ├── search.tsx
│   │   │   ├── settings.tsx
│   │   │   └── spin-wheel.tsx
│   │   ├── components/
│   │   │   ├── PersistentTabBar.tsx
│   │   │   ├── ErrorBoundary.tsx
│   │   │   ├── ErrorFallback.tsx
│   │   │   ├── GoogleSignInButton.tsx
│   │   │   ├── KeyboardAwareScrollViewCompat.tsx
│   │   │   └── skeletons/SkeletonBase.tsx
│   │   ├── contexts/
│   │   │   ├── AuthContext.tsx            ← Token + user state
│   │   │   ├── ThemeContext.tsx
│   │   │   └── ConfigContext.tsx          ← Remote app config
│   │   ├── hooks/
│   │   │   ├── useColors.ts
│   │   │   ├── useNotifications.ts
│   │   │   ├── useNotice.ts
│   │   │   └── useGoogleConfig.ts
│   │   ├── constants/colors.ts
│   │   ├── lib/
│   │   │   ├── config.ts
│   │   │   └── firebase.ts
│   │   ├── assets/images/icon.png
│   │   ├── app.json                      ← Expo config (bundle ID, permissions)
│   │   ├── babel.config.js
│   │   ├── metro.config.js
│   │   ├── tsconfig.json
│   │   └── package.json
│   │
│   └── mockup-sandbox/                   ← UI mockup preview tool (dev only)
│
└── scripts/                              ← Utility scripts
    └── post-merge.sh
```

---

## টেকনোলজি স্ট্যাক

| অংশ | টেকনোলজি |
|---|---|
| Runtime | Node.js 24 |
| Package Manager | pnpm 9 (workspaces) |
| Language | TypeScript 5.9 |
| API Server | Express 5 |
| Database | PostgreSQL + Drizzle ORM |
| Validation | Zod v4, drizzle-zod |
| API Contract | OpenAPI 3.1 → Orval codegen |
| Admin Frontend | React 19 + Vite + TanStack Query |
| UI Components | shadcn/ui + Tailwind CSS |
| Mobile | Expo SDK 55 + React Native + Expo Router |
| Auth | JWT (bcryptjs + jsonwebtoken) |
| Email | Nodemailer (SMTP) |
| Push Notifications | Firebase Cloud Messaging |
| Image Storage | Local / Supabase Storage / AWS S3 |
| PDF Generation | pdfkit |
| Build Tool | esbuild |

---

## প্রয়োজনীয় সফটওয়্যার

```bash
node --version   # 20+ প্রয়োজন, 24 রেকমেন্ডেড
pnpm --version   # 9+ প্রয়োজন
```

pnpm না থাকলে:

```bash
npm install -g pnpm
```

---

## সম্পূর্ণ সেটআপ প্রক্রিয়া

### ধাপ ১ — রিপোজিটরি ক্লোন করুন

```bash
git clone https://github.com/your-org/shohure.git
cd shohure
```

### ধাপ ২ — সব প্যাকেজ ইন্সটল করুন

```bash
pnpm install
```

> এই একটি কমান্ডেই সব workspace (api-server, admin, mobile, lib) এর dependencies ইন্সটল হয়ে যাবে।

---

### ধাপ ৩ — Environment Variables সেট করুন

প্রজেক্ট রুটে `.env` ফাইল তৈরি করুন:

```bash
cp .env.example .env   # যদি example থাকে
# অথবা নতুন ফাইল তৈরি করুন:
touch .env
```

নিচের সব ভেরিয়েবল `.env` ফাইলে যোগ করুন:

```env
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DATABASE (required)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATABASE_URL=postgresql://user:password@localhost:5432/shohure

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AUTH SECRETS (required)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# User JWT — যেকোনো লম্বা random string
SESSION_SECRET=your-super-secret-session-key-min-32-chars

# Admin JWT — আলাদা secret
ADMIN_JWT_SECRET=your-admin-jwt-secret-key

# App config encryption — ঠিক 64 hex chars (32 bytes AES-256)
CONFIG_ENCRYPTION_KEY=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SERVER (required)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PORT=3000
NODE_ENV=development

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EMAIL / SMTP (optional — OTP ও order confirmation এর জন্য)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@shohure.com
SMTP_FROM_NAME=Shohure

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# IMAGE STORAGE (optional — default: local disk)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Supabase Storage ব্যবহার করতে চাইলে:
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
SUPABASE_STORAGE_BUCKET=images

# AWS S3 ব্যবহার করতে চাইলে (admin panel থেকেও সেট করা যায়):
# AWS_ACCESS_KEY=...
# AWS_SECRET_KEY=...
# AWS_REGION=ap-south-1
# AWS_BUCKET=shohure-images

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LOGGING (optional)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LOG_LEVEL=info
```

#### Mobile App এর জন্য (`artifacts/mobile/.env`):

```env
# API server এর domain (Expo go তে লোকাল dev)
EXPO_PUBLIC_DOMAIN=192.168.1.100:3000
# অথবা production:
# EXPO_PUBLIC_DOMAIN=api.shohure.com

# Firebase (push notifications এর জন্য — optional)
EXPO_PUBLIC_FIREBASE_API_KEY=AIza...
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=shohure.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=shohure
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=shohure.appspot.com
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
EXPO_PUBLIC_FIREBASE_APP_ID=1:123456789:android:abc123
EXPO_PUBLIC_FIREBASE_MEASUREMENT_ID=G-XXXXXXXX
```

> **CONFIG_ENCRYPTION_KEY জেনারেট করতে:**
> ```bash
> node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
> ```

---

### ধাপ ৪ — PostgreSQL Database সেটআপ

#### লোকাল PostgreSQL:

```bash
# macOS (Homebrew)
brew install postgresql@16
brew services start postgresql@16

# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql

# Database তৈরি করুন
psql -U postgres
CREATE DATABASE shohure;
CREATE USER shohure_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE shohure TO shohure_user;
\q
```

#### DATABASE_URL format:

```
postgresql://shohure_user:your_password@localhost:5432/shohure
```

---

### ধাপ ৫ — Database Migration চালান

```bash
# Schema push (development)
pnpm --filter @workspace/db run push

# অথবা migration file দিয়ে (production recommended):
pnpm --filter @workspace/db run migrate
```

প্রথমবার push করলে সব টেবিল তৈরি হবে। সফল হলে এরকম দেখাবে:

```
[✓] Changes applied
```

> **প্রতিবার schema পরিবর্তন করলে** এই কমান্ড চালাতে হবে।

---

### ধাপ ৬ — সব সার্ভিস চালু করুন

তিনটি আলাদা terminal এ চালান:

**Terminal 1 — API Server:**

```bash
pnpm --filter @workspace/api-server run dev
# চালু হবে: http://localhost:3000
```

**Terminal 2 — Admin Panel:**

```bash
pnpm --filter @workspace/admin run dev
# চালু হবে: http://localhost:5173
```

**Terminal 3 — Mobile App:**

```bash
pnpm --filter @workspace/mobile run dev
# Expo Go দিয়ে QR scan করুন
# অথবা: http://localhost:19006 (web)
```

---

### ধাপ ৭ — প্রথম লগইন

#### Admin Panel:
- URL: `http://localhost:5173`
- Email: `admin@shohure.com`
- Password: `Admin@1234`

> প্রথমবার API server চালু হলে যদি কোনো user না থাকে, এই default admin account স্বয়ংক্রিয়ভাবে তৈরি হয়।

---

## সব কমান্ডের তালিকা

```bash
# ── Development ──────────────────────────────────────────
pnpm --filter @workspace/api-server run dev     # API server (port 3000)
pnpm --filter @workspace/admin run dev          # Admin panel (port 5173)
pnpm --filter @workspace/mobile run dev         # Expo mobile

# ── Build ────────────────────────────────────────────────
pnpm run build                                  # সব package build
pnpm --filter @workspace/api-server run build   # শুধু API build
pnpm --filter @workspace/admin run build        # শুধু Admin build

# ── Database ─────────────────────────────────────────────
pnpm --filter @workspace/db run push            # Schema sync (dev)
pnpm --filter @workspace/db run generate        # Migration file তৈরি
pnpm --filter @workspace/db run migrate         # Migration চালান (prod)

# ── Code Generation ──────────────────────────────────────
pnpm --filter @workspace/api-spec run codegen   # OpenAPI → React Query hooks

# ── Type Check ───────────────────────────────────────────
pnpm run typecheck                              # সব package typecheck
pnpm run typecheck:libs                         # শুধু lib packages

# ── Mobile ───────────────────────────────────────────────
pnpm --filter @workspace/mobile run dev         # Expo start
pnpm --filter @workspace/mobile run build       # Web build
```

---

## Mobile Expo Setup (বিস্তারিত)

### Expo Go দিয়ে টেস্ট করুন:

1. ফোনে **Expo Go** অ্যাপ ইন্সটল করুন (iOS/Android)
2. ফোন ও কম্পিউটার একই WiFi তে থাকুন
3. `artifacts/mobile/.env` এ `EXPO_PUBLIC_DOMAIN` সেট করুন আপনার কম্পিউটারের IP দিয়ে:
   ```env
   EXPO_PUBLIC_DOMAIN=192.168.1.100:3000
   ```
4. `pnpm --filter @workspace/mobile run dev` চালান
5. Terminal এ QR code দেখাবে — Expo Go দিয়ে স্ক্যান করুন

### iOS Simulator / Android Emulator:

```bash
# iOS (macOS only)
pnpm --filter @workspace/mobile run dev -- --ios

# Android
pnpm --filter @workspace/mobile run dev -- --android
```

### expo-file-system ও expo-sharing ইন্সটল:

```bash
pnpm --filter @workspace/mobile add expo-file-system expo-sharing
```

---

## Production Deployment

### API Server (Node.js):

```bash
# Build
pnpm --filter @workspace/api-server run build

# চালান (dist/index.mjs তৈরি হবে)
PORT=3000 NODE_ENV=production node artifacts/api-server/dist/index.mjs
```

### Admin Panel (Static):

```bash
# Build
pnpm --filter @workspace/admin run build
# dist/public/ ফোল্ডার Netlify/Vercel/Nginx এ deploy করুন
```

### Mobile App (EAS Build):

```bash
# EAS CLI ইন্সটল করুন
npm install -g eas-cli

# Login করুন
eas login

# Build config করুন
cd artifacts/mobile
eas build:configure

# Android APK/AAB build
eas build --platform android

# iOS build
eas build --platform ios
```

---

## সাধারণ সমস্যা ও সমাধান

### `DATABASE_URL` error:
```bash
Error: DATABASE_URL must be set
```
→ `.env` ফাইলে `DATABASE_URL` সঠিকভাবে সেট করুন এবং `source .env` বা dotenv ব্যবহার করুন।

### Schema push কাজ না করলে:
```bash
pnpm --filter @workspace/db run push
```
→ এই কমান্ড API server চালু করার আগে চালাতে হবে।

### `CONFIG_ENCRYPTION_KEY` error:
```bash
Error: CONFIG_ENCRYPTION_KEY must be exactly 64 hex chars
```
→ নিচের কমান্ড দিয়ে নতুন key তৈরি করুন:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Mobile app API connect করতে পারছে না:
→ `EXPO_PUBLIC_DOMAIN` এ ফোনের সাথে যোগাযোগযোগ্য IP দিন (localhost না)।
→ Firewall বন্ধ করুন অথবা port 3000 খুলুন।

### Admin login কাজ করছে না:
→ API server চালু আছে কিনা দেখুন।
→ Default credentials: `admin@shohure.com` / `Admin@1234`।
→ Database migration হয়েছে কিনা নিশ্চিত করুন।

---

## প্রজেক্টের ফিচারসমূহ

### Mobile App:
- Product browsing, categories, search
- Flash sales, promotional banners
- Cart ও Checkout (bKash, Nagad, COD)
- Order tracking with live status
- **Invoice PDF download** (share sheet দিয়ে)
- Wishlist, product reviews
- Spin wheel rewards, referral system
- Push notifications
- Google Sign-In

### Admin Panel:
- Dashboard (revenue, orders, analytics charts)
- Product management (CRUD, variants, bulk import)
- Order management + status update
- **Invoice PDF download** (browser download)
- MFS payment verification (bKash/Nagad)
- Customer & admin management
- Coupon, flash sale, banner management
- Shipping zone configuration
- App config (Firebase, SMTP, Storage)

### API:
- 20+ REST endpoints
- JWT authentication (user + admin আলাদা)
- File upload (local/Supabase/S3)
- Email OTP verification
- PDF invoice generation (pdfkit)
- Firebase push notifications
- Abandoned cart reminders (cron)

---

## Architecture সম্পর্কিত গুরুত্বপূর্ণ তথ্য

- **Contract-first**: `lib/api-spec/openapi.yaml` হলো সত্যের উৎস। Route যোগ করলে spec আপডেট করে `pnpm --filter @workspace/api-spec run codegen` চালাতে হবে।
- **দুটি আলাদা JWT**: User token (`SESSION_SECRET`) ও Admin token (`ADMIN_JWT_SECRET`) আলাদা।
- **Drizzle numeric columns**: DB থেকে `numeric` type এর মান string হিসেবে আসে — display করার আগে `parseFloat()` করতে হবে।
- **App config DB-তে encrypted**: Firebase keys, SMTP credentials সব AES-256 দিয়ে encrypt করে `appConfigTable` এ রাখা হয়।
- **Mobile base URL**: `app/_layout.tsx` এ `setBaseUrl()` দিয়ে API URL সেট হয়।

---

## সর্বশেষ বাগ ফিক্স (invoice-update১১)

এই আপডেটে মোট **৬টি** সমস্যা সমাধান করা হয়েছে:

### বাগ ফিক্স

**১. Mobile — Local Dev-এ Invoice Download কাজ করত না**
ফাইল: `artifacts/mobile/app/order/[id].tsx`

`downloadInvoice()` ফাংশনে `EXPO_PUBLIC_DOMAIN` থেকে URL বানানোর সময় সবসময় `https://` ব্যবহার করা হচ্ছিল। কিন্তু লোকাল নেটওয়ার্কে Express সার্ভার HTTP-তে চলে — TLS সার্টিফিকেট নেই। ফলে `https://192.168.x.x:3000` এ SSL error হয়ে invoice download সম্পূর্ণ ব্যর্থ হত।

**ঠিক করা হয়েছে:** `NODE_ENV` দেখে protocol বাছাই করা হয় — development-এ `http://`, production-এ `https://`।

---

**২. Admin — Back Button-এ Invalid HTML (Nested `<a>` Tag)**
ফাইল: `artifacts/admin/src/pages/orders/detail.tsx`

Wouter-এর `<Link>` component নিজেই একটি `<a>` tag রেন্ডার করে। এর ভেতরে আরেকটি `<a>` রাখা হয়েছিল — এটি W3C spec অনুযায়ী invalid HTML। ব্রাউজার এটাকে অপ্রত্যাশিতভাবে parse করে, যা click event এবং keyboard navigation ভেঙে দিতে পারে।

**ঠিক করা হয়েছে:** ভেতরের `<a>` সরিয়ে `className` সরাসরি `<Link>`-এ দেওয়া হয়েছে।

---

**৩. Mobile — "Rocket" Payment Method ভুল দেখাত**
ফাইল: `artifacts/mobile/app/order/[id].tsx`

`PAY_METHOD_LABEL` map-এ `rocket` entry ছিল না। Rocket-এ payment করা order-এর detail page-এ payment method হিসেবে raw string `"rocket"` দেখাত — ব্যবহারকারীর কাছে অদ্ভুত দেখাত।

**ঠিক করা হয়েছে:** `rocket: "Rocket"` entry যোগ করা হয়েছে।

---

**৪. Mobile — Payment Summary-তে Coins Deduction দেখাত না**
ফাইল: `artifacts/mobile/app/order/[id].tsx`

Admin panel-এ order summary-তে "Coins Used" deduction দেখায়, কিন্তু mobile app-এর একই section-এ এটি ছিল না। ফলে mobile-এ subtotal + shipping থেকে total মিলত না — ব্যবহারকারী বিভ্রান্ত হতেন।

**ঠিক করা হয়েছে:** `coinsUsed > 0` হলে সবুজ রঙে deduction row দেখানো হয়, ঠিক admin panel-এর মতো।

---

**৫. Mobile — Payment Status Badge ভুল তথ্য দেখাত**
ফাইল: `artifacts/mobile/app/order/[id].tsx`

Payment status badge-এ শুধু `paid` এবং `unpaid` handle করা ছিল। `failed`, `refunded`, `pending` যেকোনো status-এ "⏳ Unpaid" দেখাত — এটি সম্পূর্ণ ভুল তথ্য। Refunded order-এও "Unpaid" দেখানো customer complaint-এর কারণ হতে পারত।

**ঠিক করা হয়েছে:** `PAY_STATUS_CONFIG` object তৈরি করা হয়েছে যেখানে সব status-এর জন্য আলাদা label ও রঙ আছে — paid (সবুজ), pending (হলুদ), failed (লাল), refunded (ধূসর)।

---

**৬. README — পুরনো ও অপ্রয়োজনীয় ধাপ ছিল**
ফাইল: `README.md`

আগে ধাপ ৬ হিসেবে `pdfkit` manually install করার instruction ছিল। কিন্তু `pdfkit` এবং `@types/pdfkit` ইতিমধ্যেই `artifacts/api-server/package.json`-এর dependencies-এ আছে। ধাপ ২-এর `pnpm install`-এই এটি automatically install হয়ে যায়। এই অপ্রয়োজনীয় ধাপটি নতুন developer-কে বিভ্রান্ত করত এবং একই package দুইবার install করাত।

**ঠিক করা হয়েছে:** ধাপ ৬ সম্পূর্ণ সরানো হয়েছে এবং পরবর্তী ধাপগুলোর নম্বর ঠিক করা হয়েছে। Troubleshooting section থেকেও সংশ্লিষ্ট entry সরানো হয়েছে।

---

## লাইসেন্স

MIT © Shohure Team
