# Shohure — Full Setup & Deployment Guide

## Overview

Shohure is a Bangladesh e-commerce platform with four parts:

| Artifact | Tech | Purpose |
|---|---|---|
| **API Server** | Express + Drizzle + PostgreSQL | Backend — all data, auth, orders, courier |
| **Admin Panel** | React + Vite | Admin dashboard — orders, products, settings |
| **Mobile App** | Expo / React Native | Customer-facing shopping app |
| **Mockup Sandbox** | Vite | Internal UI component preview (dev only) |

---

## 1. Prerequisites

- **Node.js 24+** (managed by Replit automatically)
- **pnpm** (managed by Replit automatically)
- **PostgreSQL** database (Replit's built-in DB, Render PostgreSQL, or Neon)

---

## 2. Environment Variables (Complete List)

All secrets are managed via Replit Secrets. Never commit them to code.

### Required — API Server

| Variable | Description | How to get |
|---|---|---|
| `DATABASE_URL` | PostgreSQL connection string | Replit DB → copy URL, or Render/Neon |
| `SESSION_SECRET` | JWT signing secret | Run: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `CONFIG_ENCRYPTION_KEY` | 64-char hex key for AES-256 encryption of settings | Run: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `ADMIN_PASSWORD` | Password for the admin account | Set to a strong password (8+ chars, uppercase, number) |
| `PORT` | Server port | Set automatically by Replit/Render |

### Required — Courier (choose one or both)

| Variable | Description | How to get |
|---|---|---|
| `STEADFAST_API_KEY` | Steadfast courier API key | Login to [portal.packzy.com](https://portal.packzy.com) → Settings → API |
| `STEADFAST_SECRET_KEY` | Steadfast courier secret key | Same location as above |

### Optional — Google OAuth (for "Sign in with Google")

| Variable | Description | How to get |
|---|---|---|
| `GOOGLE_CLIENT_ID` | Google OAuth Client ID | [console.cloud.google.com](https://console.cloud.google.com) → APIs → Credentials |
| `GOOGLE_CLIENT_SECRET` | Google OAuth Client Secret | Same location |

### Optional — Email (for password reset, verification)

| Variable | Description | Example |
|---|---|---|
| `SMTP_HOST` | SMTP server hostname | `smtp.gmail.com` |
| `SMTP_PORT` | SMTP port | `587` |
| `SMTP_USER` | SMTP username/email | `noreply@shohure.com` |
| `SMTP_PASS` | SMTP password or app password | Gmail app password |
| `SMTP_FROM` | From address shown to users | `Shohure <noreply@shohure.com>` |

### Optional — Push Notifications (for mobile app)

| Variable | Description | How to get |
|---|---|---|
| `EXPO_ACCESS_TOKEN` | Expo push notification token | [expo.dev](https://expo.dev) → Account → Access Tokens |

### Optional — Admin Panel

| Variable | Description |
|---|---|
| `VITE_API_URL` | API server URL (e.g. `https://shohure-api.onrender.com`) |
| `ADMIN_EMAIL` | Admin login email (default: `admin@shohure.com`) |

### Optional — Deployment

| Variable | Description |
|---|---|
| `RENDER_EXTERNAL_URL` | Auto-set by Render — used for keep-alive pings |
| `NODE_ENV` | Set to `production` on Render |

---

## 3. Database Setup

The API server auto-runs all migrations on startup — **no manual steps needed**.

Migrations applied in order:
- `0001` — Core tables (users, products, orders, etc.)
- `0002` — MFS payment fields
- `0003` — Missing tables (reviews, gamification, messages)
- `0004` — Additional courier fields
- `0005` — Steadfast courier integration
- `0006` — Courier status polling (`last_courier_status` column)

### To connect a database:
1. In Replit: go to **Database** tab → copy `DATABASE_URL`
2. Add it as a Replit Secret named `DATABASE_URL`
3. The API server will connect automatically on next start

---

## 4. First-Time Admin Account

The server creates the admin account automatically on first start if:
- `ADMIN_EMAIL` is set (or defaults to `admin@shohure.com`)
- `ADMIN_PASSWORD` is set in Replit Secrets

If you need to reset the admin password later:
```sql
UPDATE users SET password_hash = '<new_bcrypt_hash>' WHERE email = 'admin@shohure.com';
```

---

## 5. Admin Panel Setup

The admin panel (`/admin`) connects to the API server.

### Local Development
The panel auto-detects `VITE_API_URL`. In Replit it falls back to the dev proxy.

### Production
Set `VITE_API_URL` in Replit Secrets to your deployed API URL:
```
VITE_API_URL=https://your-api.onrender.com
```

### Login
- URL: `https://your-domain/admin`
- Email: value of `ADMIN_EMAIL` (default: `admin@shohure.com`)
- Password: value of `ADMIN_PASSWORD`

---

## 6. Mobile App Setup

### Running in Development
The mobile app uses Expo. In Replit, scan the QR code from the Expo workflow to open in Expo Go.

### API URL
Set in `artifacts/mobile/lib/config.ts`. For production, change to your deployed API URL:
```typescript
export const API_BASE_URL = "https://your-api.onrender.com";
```

### Building for Production
```bash
cd artifacts/mobile
pnpm exec eas build --platform android  # or ios
```

---

## 7. Courier Integration

### Steadfast Courier (portal.packzy.com)

1. Create an account at [portal.packzy.com](https://portal.packzy.com)
2. Go to **Settings → API**
3. Copy your **API Key** and **Secret Key**
4. Add them as Replit Secrets:
   - `STEADFAST_API_KEY`
   - `STEADFAST_SECRET_KEY`
5. In the Admin Panel → **Settings → Courier Services**:
   - Toggle **Enable Steadfast** ON
   - Toggle **Auto-submit to courier on confirm** ON
   - Set **Active Courier** to Steadfast

**How it works:**
- When you confirm a home-delivery order → Steadfast consignment is auto-created
- Tracking code is saved to the order and shown in admin + mobile
- The courier status cron runs every 30 minutes, detects status changes, and sends push notifications to the customer

### Carrybee Courier (developers.carrybee.com)

1. Get your credentials from Carrybee
2. In the Admin Panel → **Settings → Courier Services**:
   - Enter **Client ID**, **Client Secret**, **Client Context**, **Store ID**
   - Toggle **Enable Carrybee** ON
   - Set **Active Courier** to Carrybee

---

## 8. Push Notifications

1. Create an Expo account at [expo.dev](https://expo.dev)
2. Go to **Account → Access Tokens → Create Token**
3. Add as `EXPO_ACCESS_TOKEN` in Replit Secrets
4. Users must grant notification permission in the mobile app (prompted on first launch)

Push notifications are sent for:
- Order placed
- Order status changes (confirmed, shipped, delivered, etc.)
- Courier status changes (Steadfast/Carrybee, every 30 min poll)
- Payment verified
- Abandoned cart reminders (24h after cart inactivity)

---

## 9. Email Setup (Password Reset & Verification)

For Gmail:
1. Enable 2FA on your Gmail account
2. Go to **Google Account → Security → App Passwords**
3. Create an app password for "Mail"
4. Set these secrets:
   ```
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=your@gmail.com
   SMTP_PASS=your-app-password
   SMTP_FROM=Shohure <your@gmail.com>
   ```

---

## 10. Deploying to Production (Render)

### API Server
1. Create a new **Web Service** on [render.com](https://render.com)
2. Connect your GitHub repo
3. Set:
   - **Build Command:** `pnpm install && pnpm --filter @workspace/api-server run build`
   - **Start Command:** `node artifacts/api-server/dist/index.mjs`
   - **Environment:** Add all secrets from Section 2
4. Add a **PostgreSQL** database on Render → copy the Internal URL as `DATABASE_URL`

### Admin Panel
Deploy as a **Static Site** on Render or Vercel:
- **Build Command:** `pnpm install && pnpm --filter @workspace/admin run build`
- **Publish Directory:** `artifacts/admin/dist`
- **Environment Variable:** `VITE_API_URL=https://your-api.onrender.com`

---

## 11. Key Admin Panel Features

| Page | What it does |
|---|---|
| **Dashboard** | Revenue, orders, users analytics |
| **Orders** | View, confirm, update status, verify payment, submit to courier |
| **Order Detail** | Full order info + courier tracking (Steadfast/Carrybee) with live status |
| **Products** | Add/edit products, variants, stock, images |
| **Brands & Categories** | Manage brand/category hierarchy |
| **Coupons** | Create discount codes (flat or percent, expiry, usage limits) |
| **Flash Sales** | Time-limited sale events |
| **Banners** | Homepage banner images with deep links |
| **Promo Cards** | Home screen promotional tiles |
| **Stores** | Pickup store locations |
| **Shipping Zones** | Per-district shipping fee rules |
| **Messages** | Customer support chat |
| **Settings** | Courier config, coin system, app config |

---

## 12. Automatic Background Jobs

| Job | Frequency | What it does |
|---|---|---|
| **Courier Status Cron** | Every 30 min | Polls Steadfast/Carrybee for status changes, sends push notification if changed, auto-marks delivered |
| **Abandoned Cart Cron** | Every 1 hour | Finds carts idle for 24h, sends push reminder |
| **Keep-Alive Ping** | Every 10 min | Pings `/api/healthz` to prevent Render from sleeping |

---

## 13. Security Notes

- `SESSION_SECRET` must be at least 32 random characters — never use a simple word
- `CONFIG_ENCRYPTION_KEY` must be exactly 64 hex characters (32 bytes) — settings are stored AES-256 encrypted
- The seed reset endpoint (`POST /admin/seed/reset`) is blocked in `NODE_ENV=production` unless `ALLOW_SEED_RESET=true` is explicitly set — **never set this in production**
- Passwords require: 8+ characters, at least 1 uppercase letter, at least 1 number
- All admin routes require a valid JWT with role `owner` or `manager`

---

## 14. Generating Required Keys

```bash
# SESSION_SECRET (32 random bytes → 64 hex chars)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# CONFIG_ENCRYPTION_KEY (same format)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## 15. Troubleshooting

| Problem | Solution |
|---|---|
| Admin login fails | Check `ADMIN_PASSWORD` secret is set; check the hash in DB matches |
| Steadfast not creating consignments | Verify `STEADFAST_API_KEY` and `STEADFAST_SECRET_KEY` are set; check admin Settings → Courier has Steadfast enabled + auto-submit ON |
| Push notifications not arriving | Check `EXPO_ACCESS_TOKEN` is set; user must have granted notification permission |
| Email not sending | Verify SMTP credentials; for Gmail use an App Password, not your main password |
| Orders page shows no data | Check `VITE_API_URL` points to the correct API server |
| Database migration errors | Check `DATABASE_URL` is correct and the DB user has CREATE TABLE privileges |
| Server crashes on startup | Check `SESSION_SECRET` and `CONFIG_ENCRYPTION_KEY` are both set correctly |
