import React, { useState } from "react";
import { useListCategories, useCreateCategory, useDeleteCategory, useUpdateCategory, getListCategoriesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ImageUpload } from "@/components/image-upload";
import { Plus, Trash2, Pencil, X, Check, Image as ImageIcon } from "lucide-react";

type Category = { id: number; name: string; slug: string; imageUrl?: string | null; productCount: number };

export default function Categories() {
  const { data: categories, isLoading } = useListCategories();
  const createCategory = useCreateCategory();
  const deleteCategory = useDeleteCategory();
  const updateCategory = useUpdateCategory();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  const [editId, setEditId] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [editSlug, setEditSlug] = useState("");
  const [editImageUrl, setEditImageUrl] = useState("");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createCategory.mutate(
      { data: { name, slug, imageUrl: imageUrl || undefined } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
          setName(""); setSlug(""); setImageUrl("");
          toast({ title: "Category created" });
        },
        onError: () => toast({ title: "Failed to create", variant: "destructive" }),
      }
    );
  };

  const startEdit = (cat: Category) => {
    setEditId(cat.id);
    setEditName(cat.name);
    setEditSlug(cat.slug);
    setEditImageUrl(cat.imageUrl ?? "");
  };

  const cancelEdit = () => setEditId(null);

  const saveEdit = (id: number) => {
    updateCategory.mutate(
      { id, data: { name: editName, slug: editSlug, imageUrl: editImageUrl || undefined } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
          setEditId(null);
          toast({ title: "Category updated" });
        },
        onError: () => toast({ title: "Failed to update", variant: "destructive" }),
      }
    );
  };

  const handleDelete = (id: number) => {
    if (!confirm("Delete this category?")) return;
    deleteCategory.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() });
        toast({ title: "Category deleted" });
      }
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight text-gray-900">Categories</h2>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-4">Add Category</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <ImageUpload label="Category Image" value={imageUrl} onChange={setImageUrl} />
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <Input value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Slug</label>
                <Input value={slug} onChange={(e) => setSlug(e.target.value)} required placeholder="e.g. electronics" />
              </div>
              <Button type="submit" disabled={createCategory.isPending} className="w-full">
                <Plus className="h-4 w-4 mr-2" /> Add Category
              </Button>
            </form>
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="p-8 text-center text-gray-500">Loading...</div>
            ) : (
              <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-4">Image</th>
                    <th className="px-4 py-4">Name</th>
                    <th className="px-4 py-4">Products</th>
                    <th className="px-4 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {categories?.map((cat) => (
                    <tr key={cat.id} className="hover:bg-gray-50">
                      {editId === cat.id ? (
                        <td colSpan={4} className="px-4 py-4">
                          <div className="space-y-3">
                            <ImageUpload label="Image" value={editImageUrl} onChange={setEditImageUrl} />
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-xs font-medium mb-1">Name</label>
                                <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="h-8 text-sm" />
                              </div>
                              <div>
                                <label className="block text-xs font-medium mb-1">Slug</label>
                                <Input value={editSlug} onChange={(e) => setEditSlug(e.target.value)} className="h-8 text-sm" />
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => saveEdit(cat.id)} disabled={updateCategory.isPending}>
                                <Check className="h-3.5 w-3.5 mr-1" /> Save
                              </Button>
                              <Button size="sm" variant="outline" onClick={cancelEdit}>
                                <X className="h-3.5 w-3.5 mr-1" /> Cancel
                              </Button>
                            </div>
                          </div>
                        </td>
                      ) : (
                        <>
                          <td className="px-4 py-4">
                            <div className="h-10 w-10 rounded bg-gray-100 border flex items-center justify-center overflow-hidden">
                              {cat.imageUrl ? <img src={cat.imageUrl} alt={cat.name} className="w-full h-full object-cover" /> : <ImageIcon className="h-4 w-4 text-gray-400" />}
                            </div>
                          </td>
                          <td className="px-4 py-4 font-medium">{cat.name}</td>
                          <td className="px-4 py-4 text-gray-500">{cat.productCount}</td>
                          <td className="px-4 py-4 text-right flex items-center justify-end gap-1">
                            <Button variant="ghost" size="icon" className="text-blue-600 hover:bg-blue-50" onClick={() => startEdit(cat)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-red-600 hover:bg-red-50" onClick={() => handleDelete(cat.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                  {!categories?.length && (
                    <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-500">No categories found</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
