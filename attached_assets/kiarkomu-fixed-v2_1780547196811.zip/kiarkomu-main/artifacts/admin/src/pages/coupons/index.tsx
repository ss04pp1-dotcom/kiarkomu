import React, { useState } from "react";
import { useListCoupons, useCreateCoupon, useDeleteCoupon, useUpdateCoupon, getListCouponsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, ToggleLeft, ToggleRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Coupons() {
  const { data, isLoading } = useListCoupons();
  const createCoupon = useCreateCoupon();
  const deleteCoupon = useDeleteCoupon();
  const updateCoupon = useUpdateCoupon();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [form, setForm] = useState({ code: "", type: "percent" as "percent" | "fixed", value: "", minOrder: "" });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createCoupon.mutate(
      { data: { code: form.code, type: form.type, value: parseFloat(form.value), minOrderAmount: form.minOrder ? parseFloat(form.minOrder) : undefined } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCouponsQueryKey() });
          setForm({ code: "", type: "percent", value: "", minOrder: "" });
          toast({ title: "Coupon created" });
        },
        onError: () => toast({ title: "Failed to create coupon", variant: "destructive" }),
      }
    );
  };

  const toggleActive = (c: any) => {
    updateCoupon.mutate({ id: c.id, data: { isActive: !c.isActive } as any }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListCouponsQueryKey() }),
    });
  };

  const handleDelete = (id: number) => {
    if (!confirm("Delete this coupon?")) return;
    deleteCoupon.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCouponsQueryKey() });
        toast({ title: "Coupon deleted" });
      }
    });
  };

  const coupons = (data as any)?.coupons ?? data ?? [];

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight text-gray-900">Coupons</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h3 className="text-lg font-medium mb-4">Create Coupon</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Code</label>
                <Input value={form.code} onChange={(e) => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))} required placeholder="SAVE20" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Type</label>
                <select className="w-full border rounded-md px-3 py-2 text-sm" value={form.type} onChange={(e) => setForm(f => ({ ...f, type: e.target.value as any }))}>
                  <option value="percent">Percentage (%)</option>
                  <option value="fixed">Fixed Amount (৳)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Value</label>
                <Input type="number" min="0" value={form.value} onChange={(e) => setForm(f => ({ ...f, value: e.target.value }))} required placeholder={form.type === "percent" ? "20" : "100"} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Min Order (৳)</label>
                <Input type="number" min="0" value={form.minOrder} onChange={(e) => setForm(f => ({ ...f, minOrder: e.target.value }))} placeholder="Optional" />
              </div>
              <Button type="submit" disabled={createCoupon.isPending} className="w-full">
                <Plus className="h-4 w-4 mr-2" /> Create Coupon
              </Button>
            </form>
          </div>
        </div>
        <div className="md:col-span-2">
          <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="p-8 text-center text-gray-500">Loading...</div>
            ) : (
              <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-4">Code</th>
                    <th className="px-6 py-4">Discount</th>
                    <th className="px-6 py-4">Used</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {coupons.map((c: any) => (
                    <tr key={c.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-mono font-bold">{c.code}</td>
                      <td className="px-6 py-4">{c.type === "percent" ? `${c.value}%` : `৳${c.value}`}</td>
                      <td className="px-6 py-4 text-gray-500">{c.usedCount ?? 0}</td>
                      <td className="px-6 py-4">
                        <Badge variant={c.isActive ? "default" : "secondary"}>{c.isActive ? "Active" : "Inactive"}</Badge>
                      </td>
                      <td className="px-6 py-4 text-right flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => toggleActive(c)} title={c.isActive ? "Deactivate" : "Activate"}>
                          {c.isActive ? <ToggleRight className="h-4 w-4 text-green-600" /> : <ToggleLeft className="h-4 w-4 text-gray-400" />}
                        </Button>
                        <Button variant="ghost" size="icon" className="text-red-600 hover:bg-red-50" onClick={() => handleDelete(c.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                  {!coupons.length && (
                    <tr><td colSpan={5} className="px-6 py-8 text-center text-gray-500">No coupons yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
