export const runtime = "edge";

import { ChevronRight } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { fetchProducts, fetchCategories } from "@/lib/data";
import CategoryClient from "@/components/CategoryClient";

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  const [allCategories, categoryProducts] = await Promise.all([
    fetchCategories(),
    fetchProducts({ categorySlug: slug }),
  ]);

  const category = allCategories.find(c => c.id === slug);
  if (!category) return notFound();

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <nav className="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <Link href="/" className="hover:text-[#F0185A]">Home</Link>
        <ChevronRight className="w-3 h-3" />
        <span className="text-gray-800 font-medium">{category.name}</span>
      </nav>

      <CategoryClient
        slug={slug}
        category={category}
        allCategories={allCategories}
        initialProducts={categoryProducts}
      />
    </div>
  );
}
