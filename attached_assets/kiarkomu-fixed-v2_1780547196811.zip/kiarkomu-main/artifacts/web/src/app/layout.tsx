import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ServiceWorkerCleanup from "@/components/ServiceWorkerCleanup";
import Providers from "@/components/Providers";
import WhatsAppButton from "@/components/WhatsAppButton";
import NoticeBoard from "@/components/NoticeBoard";
import { fetchCategories } from "@/lib/data";

export const metadata: Metadata = {
  title: "Shohure - Bangladesh's Trusted Online Shop",
  description: "Shop electronics, fashion, home & living and more at the best prices.",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const cats = await fetchCategories();

  return (
    <html lang="en">
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{if('serviceWorker' in navigator){navigator.serviceWorker.getRegistrations().then(function(r){r.forEach(function(sw){sw.unregister();});})}if(window.caches){caches.keys().then(function(k){k.forEach(function(c){caches.delete(c);})})};}catch(e){}})();`,
          }}
        />
      </head>
      <body>
        <Providers>
          <ServiceWorkerCleanup />
          <NoticeBoard />
          <Header categories={cats} />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
        </Providers>
      </body>
    </html>
  );
}
