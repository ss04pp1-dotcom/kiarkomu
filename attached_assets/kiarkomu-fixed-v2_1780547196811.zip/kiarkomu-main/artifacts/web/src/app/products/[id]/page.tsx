import { notFound } from "next/navigation";
import { fetchProductById, fetchProducts } from "@/lib/data";
import ProductDetailClient from "@/components/ProductDetailClient";

export const runtime = "edge";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const [product, allProducts] = await Promise.all([
    fetchProductById(id),
    fetchProducts({ limit: 20 }),
  ]);

  if (!product) return notFound();

  const related = allProducts
    .filter(p => p.id !== id && p.category === product.category)
    .slice(0, 4);
  const fallbackRelated = allProducts.filter(p => p.id !== id).slice(0, 4);

  return (
    <ProductDetailClient
      product={product}
      related={related.length > 0 ? related : fallbackRelated}
    />
  );
}
