"use client";
import { useQuery } from "@tanstack/react-query";
import { API_BASE_URL } from "./config";

export interface PublicConfig {
  siteName?: string | null;
  whatsappNumber?: string | null;
  googleClientId?: string | null;
  googleWebClientId?: string | null;
  googleAndroidClientId?: string | null;
  googleIosClientId?: string | null;
  primaryColor?: string | null;
  announcementText?: string | null;
  promoCardsJson?: string | null;
  enableFreeDelivery?: boolean;
  freeDeliveryThreshold?: number;
  codEnabled?: boolean;
  bkashEnabled?: boolean;
  nagadEnabled?: boolean;
  rocketEnabled?: boolean;
  cardEnabled?: boolean;
  payDeliveryChargeEnabled?: boolean;
  privacyPolicyUrl?: string | null;
  termsOfServiceUrl?: string | null;
  bkashNumber?: string | null;
  nagadNumber?: string | null;
  rocketNumber?: string | null;
  bkashLogoUrl?: string | null;
  nagadLogoUrl?: string | null;
  rocketLogoUrl?: string | null;
  bkashNumberLabel?: string | null;
  nagadNumberLabel?: string | null;
  rocketNumberLabel?: string | null;
  bkashTxnLabel?: string | null;
  nagadTxnLabel?: string | null;
  rocketTxnLabel?: string | null;
}

export function usePublicConfig() {
  return useQuery<PublicConfig>({
    queryKey: ["publicConfig"],
    queryFn: async ({ signal }) => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/config/mobile`, { signal });
        if (!res.ok) return {};
        return res.json();
      } catch {
        return {};
      }
    },
    staleTime: 5 * 60 * 1000,
  });
}
