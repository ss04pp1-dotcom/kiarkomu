import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, usersTable, productsTable, orderItemsTable } from "@workspace/db";
import { eq, sql, and, gte, inArray } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/requireAuth.js";

const router = Router();

router.get("/analytics/summary", requireAuth, requireRole("owner", "manager"), async (_req, res) => {
  const [rev] = await db.select({ total: sql<number>`coalesce(sum(total::numeric), 0)` }).from(ordersTable).where(eq(ordersTable.paymentStatus, "paid"));
  const [orders] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(ordersTable);
  const [customers] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(usersTable).where(eq(usersTable.role, "customer"));
  const [products] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(productsTable).where(eq(productsTable.isActive, true));
  const [pending] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(ordersTable).where(eq(ordersTable.status, "pending"));
  const today = new Date(); today.setUTCHours(0, 0, 0, 0);
  const [todayRev] = await db.select({ total: sql<number>`coalesce(sum(total::numeric), 0)` }).from(ordersTable).where(and(eq(ordersTable.paymentStatus, "paid"), gte(ordersTable.createdAt, today)));
  const [todayOrders] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(ordersTable).where(gte(ordersTable.createdAt, today));
  const avgOrderValue = orders.count > 0 ? (rev.total ?? 0) / orders.count : 0;
  res.json({
    totalRevenue: rev.total ?? 0, totalOrders: orders.count, totalCustomers: customers.count,
    totalProducts: products.count, pendingOrders: pending.count, averageOrderValue: avgOrderValue,
    revenueToday: todayRev.total ?? 0, ordersToday: todayOrders.count,
  });
});

router.get("/analytics/sales-over-time", requireAuth, requireRole("owner", "manager"), async (req, res) => {
  const { period = "daily" } = req.query as any;
  const groupBy = period === "monthly" ? sql`date_trunc('month', created_at)` : period === "weekly" ? sql`date_trunc('week', created_at)` : sql`date_trunc('day', created_at)`;
  const data = await db.select({ date: groupBy, revenue: sql<number>`coalesce(sum(total::numeric), 0)`, orders: sql<number>`cast(count(*) as int)` }).from(ordersTable).groupBy(groupBy).orderBy(groupBy).limit(30);
  res.json(data.map((d: any) => ({ date: new Date(d.date).toISOString().split("T")[0], revenue: d.revenue, orders: d.orders })));
});

router.get("/analytics/top-products", requireAuth, requireRole("owner", "manager"), async (req, res) => {
  const limit = parseInt((req.query.limit as string) ?? "10");
  const data = await db.select({ productId: orderItemsTable.productId, productName: orderItemsTable.productName, thumbnailUrl: orderItemsTable.thumbnailUrl, totalSold: sql<number>`cast(sum(quantity) as int)`, revenue: sql<number>`sum(price::numeric * quantity)` }).from(orderItemsTable).groupBy(orderItemsTable.productId, orderItemsTable.productName, orderItemsTable.thumbnailUrl).orderBy(sql`sum(quantity) desc`).limit(limit);
  res.json(data);
});

router.get("/analytics/top-categories", requireAuth, requireRole("owner", "manager"), async (_req, res) => {
  const { categoriesTable } = await import("@workspace/db");
  const data = await db.select({ categoryId: productsTable.categoryId, totalOrders: sql<number>`cast(count(distinct ${orderItemsTable.orderId}) as int)`, revenue: sql<number>`coalesce(sum(${orderItemsTable.price}::numeric * ${orderItemsTable.quantity}), 0)` }).from(orderItemsTable).leftJoin(productsTable, eq(orderItemsTable.productId, productsTable.id)).groupBy(productsTable.categoryId).orderBy(sql`sum(${orderItemsTable.price}::numeric * ${orderItemsTable.quantity}) desc`);
  const cats = await db.select().from(categoriesTable);
  const catMap = Object.fromEntries(cats.map(c => [c.id, c.name]));
  res.json(data.map(d => ({ categoryId: d.categoryId, categoryName: catMap[d.categoryId!] ?? "Unknown", totalOrders: d.totalOrders, revenue: d.revenue })));
});


// ── Feature 7: Advanced Analytics ──

// Conversion Rate: (total orders / total product views)
router.get("/analytics/conversion-rate", requireAuth, requireRole("owner", "manager"), async (_req, res) => {
  const { recentlyViewedTable } = await import("@workspace/db");
  const [orderCount] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(ordersTable);
  const [viewCount] = await db.select({ count: sql<number>`cast(count(*) as int)` }).from(recentlyViewedTable);
  const rate = viewCount.count > 0 ? (orderCount.count / viewCount.count) * 100 : 0;
  res.json({
    totalOrders: orderCount.count,
    totalViews: viewCount.count,
    conversionRate: parseFloat(rate.toFixed(2)),
  });
});

// Most Viewed Products with low sales (high views, low purchases)
router.get("/analytics/high-view-low-sale", requireAuth, requireRole("owner", "manager"), async (req, res) => {
  const { recentlyViewedTable } = await import("@workspace/db");
  const limit = parseInt((req.query.limit as string) ?? "10");

  const viewData = await db
    .select({
      productId: recentlyViewedTable.productId,
      viewCount: sql<number>`cast(count(*) as int)`,
    })
    .from(recentlyViewedTable)
    .groupBy(recentlyViewedTable.productId)
    .orderBy(sql`count(*) desc`)
    .limit(limit * 2); // fetch extra so we can sort by view:sale ratio

  if (!viewData.length) { res.json([]); return; }

  const productIds = viewData.map(v => v.productId);
  const salesData = await db
    .select({
      productId: orderItemsTable.productId,
      totalSold: sql<number>`cast(sum(quantity) as int)`,
    })
    .from(orderItemsTable)
    .where(inArray(orderItemsTable.productId, productIds))
    .groupBy(orderItemsTable.productId);

  const salesMap = Object.fromEntries(salesData.map(s => [s.productId, s.totalSold]));

  const products = await db
    .select({ id: productsTable.id, name: productsTable.name, thumbnailUrl: productsTable.thumbnailUrl, price: productsTable.price })
    .from(productsTable)
    .where(inArray(productsTable.id, productIds));
  const productMap = Object.fromEntries(products.map(p => [p.id, p]));

  const result = viewData
    .map(v => ({
      productId: v.productId,
      name: productMap[v.productId]?.name ?? "Unknown",
      thumbnailUrl: productMap[v.productId]?.thumbnailUrl ?? null,
      price: productMap[v.productId]?.price ? parseFloat(productMap[v.productId]!.price) : 0,
      viewCount: v.viewCount,
      totalSold: salesMap[v.productId] ?? 0,
      viewToSaleRatio: v.viewCount / Math.max(1, salesMap[v.productId] ?? 0),
    }))
    .sort((a, b) => b.viewToSaleRatio - a.viewToSaleRatio)
    .slice(0, limit);

  res.json(result);
});

// Top customers by total spend on paid orders
router.get("/analytics/top-customers", requireAuth, requireRole("owner", "manager"), async (req, res) => {
  const limit = parseInt((req.query.limit as string) ?? "10");

  const data = await db
    .select({
      userId: ordersTable.userId,
      totalSpend: sql<number>`cast(sum(total::numeric) as float)`,
      orderCount: sql<number>`cast(count(*) as int)`,
    })
    .from(ordersTable)
    .where(eq(ordersTable.paymentStatus, "paid"))
    .groupBy(ordersTable.userId)
    .orderBy(sql`sum(total::numeric) desc`)
    .limit(limit);

  if (!data.length) { res.json([]); return; }

  const userIds = data.map(d => d.userId);
  const users = await db
    .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, avatarUrl: usersTable.avatarUrl })
    .from(usersTable)
    .where(inArray(usersTable.id, userIds));
  const userMap = Object.fromEntries(users.map(u => [u.id, u]));

  res.json(data.map((d, i) => ({
    rank: i + 1,
    userId: d.userId,
    name: userMap[d.userId]?.name ?? "Unknown",
    email: userMap[d.userId]?.email ?? "",
    avatarUrl: userMap[d.userId]?.avatarUrl ?? null,
    totalSpend: parseFloat(d.totalSpend.toFixed(2)),
    orderCount: d.orderCount,
  })));
});

export default router;
